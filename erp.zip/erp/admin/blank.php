<?php
include("partial/header.php");
include("partial/nav.php");

?>


<?PHP
include_once("partial/footer.php");
?>