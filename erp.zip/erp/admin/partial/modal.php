<!-- 

<div class="modal fade bd-example-modal-xl" id="product_status_check" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header ">
                <h4 class="modal-title">Product_status_check</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <div>
    <div class="table-responsive table-striped mt-4">
        <table id="example" class="table table-striped dt-responsive nowrap" style="width:100%">
            <thead class="table-primary">

                <tr>
                
                        <th>Product_id</th>
                        <th>Name</th>
                        <th>status</th>
                        
                </tr>
            </thead>

            <tbody class="table-group-divider">

                <?php
                // $sql = "select product.id, `product_id`, category.categoryName, `productName`, `productQuantity`, `productPurchasePrice`, `productSalesPrice`, `productStatus`, `productMinimumQuantity`, `productSKN`, `productHsn`, `productBatch`,`productStatus` from product join category on category.category_id=product.category_id";
                //  $productList = json_decode($product->joinQuery($sql), true);
                
                
                //     foreach ($productList as $productListitem) {
                //         echo "<tr class='table-danger'>";
                       
                //         echo "<td scope='row'>" . $productListitem['product_id'] . "</td>";
                //         echo "<td scope='row'>" . $productListitem['productName'] . "</td>";
                        
                //        echo "<td scope='row'>".status($productListitem['productStatus'])."</td>";
                  


                //         echo ' <form action="code.php" method="post" >';
                //         echo ' <form action="code.php" method="post">';
                //         //echo "<input type='hidden'id='id' name='id' value='" . $productListitem["id"] . "'>";
                //         //  echo "<td><input type='submit'id='doc_edit' name='doc_delete' value='Adddress' class='btn btn-success btn-sm'></td>";
                //         // echo "<td><input type='submit'id='doc_edit' name='doc_delete' value='Edit' class='btn btn-success btn-sm'></td>";
                //         // echo "<td><input type='submit'id='doc_delete' name='doc_delete' value='Delete' class='btn btn-danger btn-sm'></td>";
                    
                //         echo "</tr>";
                //         echo '</form>';
                //     }
                ?>
            </tbody>
            <tfoot>

            </tfoot>
        </table>
    </div>

</div>
                 -->
            </div>
        </div>
    </div>
</div> 