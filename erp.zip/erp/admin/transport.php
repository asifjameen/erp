<?php
include("partial/header.php");
include("partial/nav.php");
print_r($customer->splitLastid());
?>


<?PHP
include_once("partial/footer.php");
?>